class NodeVary {

	constructor( name, type ) {

		this.isNodeVary = true;

		this.name = name;
		this.type = type;

	}

}

export default NodeVary;
